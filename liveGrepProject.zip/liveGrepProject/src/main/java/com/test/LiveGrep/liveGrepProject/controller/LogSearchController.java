package com.test.LiveGrep.liveGrepProject.controller;
import com.test.LiveGrep.liveGrepProject.service.FileProcessor;
import com.test.LiveGrep.liveGrepProject.service.FileSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LogSearchController {

    @Autowired
    private FileSearchService fileSearchService; // No longer used,

    @Autowired
    private FileProcessor fileProcessor;

    @GetMapping("/grep")
    public void grepLogs(
        @RequestParam(required = false) String directory,
        @RequestParam String regex,
        @RequestParam(required = false) String dateRange
    ) {
//        List<String> matches = fileSearchService.findMatchingLines(directory, regex, dateRange);
//        return ResponseEntity.ok(matches);

        fileProcessor.process(directory, regex, dateRange);
    }
}
