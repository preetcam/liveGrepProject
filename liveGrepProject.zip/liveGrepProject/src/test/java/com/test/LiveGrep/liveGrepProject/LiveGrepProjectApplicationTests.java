package com.test.LiveGrep.liveGrepProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveGrepProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
